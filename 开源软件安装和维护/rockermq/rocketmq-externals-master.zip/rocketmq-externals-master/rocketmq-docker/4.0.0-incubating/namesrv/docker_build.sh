#!/bin/bash 

sudo docker build -t apache/incubator-rocketmq-namesrv:4.0.0-incubating .
