#!/bin/bash

sudo docker build -t apache/incubator-rocketmq-broker:4.1.0-incubating .
